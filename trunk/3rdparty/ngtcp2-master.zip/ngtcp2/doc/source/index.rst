.. ngtcp2 documentation master file, created by
   sphinx-quickstart on Mon Nov 30 22:15:12 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to ngtcp2's documentation!
==================================

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   programmers-guide
   apiref
   crypto_apiref

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
